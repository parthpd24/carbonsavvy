#pragma once

class Algo
{
public:
	struct
	{
		int coalkWh;
		int natGaskWh;
		int hydEleckWh;
		int oilkWh;
	} elecVars; //The default values 

	struct
	{
		float coalFoot;
		float natGasFoot;
		float hydElecFoot;
		float oilFoot;
		float elecFoot;

	} elecFoot;

	int CalcElectricFootprint(float coalFoot, float natGasFoot, float hydElecFoot, float oilFoot);
	float CalcCoalFootprint(int coalkWh);
	float CalcNatGasFootPrint(int natGaskWh);
	float CalcHydElecFootPrint(int hydEleckWh);
	float CalcOilFootprint(int oilkWh);

};

