#include "StdAfx.h"
#include "Algo.h"

int Algo::CalcElectricFootprint(float coalFoot, float natGasFoot, float hydElecFoot, float oilFoot) //Final Equation for electricity carbon footprint
{
	int FinalElecFootprint = 0;
	float TotalElecFootprint = coalFoot + natGasFoot + hydElecFoot + oilFoot;

	FinalElecFootprint = TotalElecFootprint;
	return FinalElecFootprint;
}

float Algo::CalcCoalFootprint(int coalkWh) //Convert Coal KiloWatt Hours into Carbon Data
{
	float coalOutput = coalkWh * 1945.00464 * 0.2552;

	return coalOutput;
}
float Algo::CalcNatGasFootPrint(int natGaskWh) //Convert Natural Gas KiloWatt Hours into Carbon Data
{
	float natGasOutput = natGaskWh * 0.003715182 * 0.2001;

	return natGasOutput;
}
float Algo::CalcHydElecFootPrint(int hydEleckWh) //Convert Hydroelectricity KiloWatt Hours into Carbon Data
{
	float hydElecOutput = hydEleckWh * 0.000011 * 0.0005;

	return hydElecOutput;
}
float Algo::CalcOilFootprint(int oilkWh) //Convert Oil KiloWatt Hours into Carbon Data
{
	float oilOutput = oilkWh * 0.0026 * 0.008759688;

	return oilOutput;
}

