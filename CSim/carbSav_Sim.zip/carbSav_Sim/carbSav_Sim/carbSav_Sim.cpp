// carbSav_Sim.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Windows.h"
#include "Algo.h"

using namespace std;

int main()
{
	Algo Algo; //Initialize Algorithm Class and Call Functions

	/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=STARTING PHRASES=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

	system("Color A");
	std::cout << "Welcome to the Simulation for your Carbon Footprint! (Only Electric ATM)" << std::endl << std::endl;
	Sleep(1000);
	std::cout << "We will calculate your Carbon Footprint using this simulation." << endl << std::endl;
	Sleep(1000);

	/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-USER INPUT-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

	// Coal Usage
	std::cout << "First enter your Kilowatt Hours per Year for your coal usage." << endl;
	std::cin >> Algo.elecVars.coalkWh;

	Algo.elecFoot.coalFoot = Algo.CalcCoalFootprint(Algo.elecVars.coalkWh);

	// Natural Gas Usage
	std::cout << "First enter your Kilowatt Hours per Year for your natural gas usage." << endl;
	std::cin >> Algo.elecVars.natGaskWh;

	Algo.elecFoot.natGasFoot = Algo.CalcNatGasFootPrint(Algo.elecVars.natGaskWh);

	// Hydroelectricity Usage
	std::cout << "First enter your Kilowatt Hours per Year for your hydroelectricity usage." << endl;
	std::cin >> Algo.elecVars.hydEleckWh;

	Algo.elecFoot.hydElecFoot = Algo.CalcHydElecFootPrint(Algo.elecVars.hydEleckWh);

	// Oil Usage

	std::cout << "First enter your Kilowatt Hours per Year for your oil usage." << endl;
	std::cin >> Algo.elecVars.oilkWh;

	Algo.elecFoot.oilFoot = Algo.CalcOilFootprint(Algo.elecVars.oilkWh);

	/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-CARBON FOOTPRINT-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

	std::cout << "Calculating your Electric Carbon Footprint.";
	Sleep(1000);
	std::cout << ".";
	Sleep(1000);
	std::cout << ".";
	Sleep(1000);
	std::cout << ".";
	Sleep(1000);
	cout << std::endl;

	//Run Total Function
	Algo.elecFoot.elecFoot = Algo.CalcElectricFootprint(Algo.elecFoot.coalFoot, Algo.elecFoot.natGasFoot, Algo.elecFoot.hydElecFoot, Algo.elecFoot.oilFoot);

	std::cout << "Your Electric Carbon Footprint is..." << endl;
	std::cout << Algo.elecFoot.elecFoot << "!!!" << endl;

	return 0;
}

